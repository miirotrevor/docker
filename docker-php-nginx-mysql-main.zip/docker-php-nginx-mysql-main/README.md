# docker-php-nginx-mysql
Nginx, PHP, MySQL Stack on Docker
